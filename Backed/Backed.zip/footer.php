  <footer class="footer text-center"> <?php echo date('Y'); ?> &copy; DCSHRM  </footer>
